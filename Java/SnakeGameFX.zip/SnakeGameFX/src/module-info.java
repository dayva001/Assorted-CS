module SnakeGameFX {
	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
	
	exports application;
}
