module JavaFX_Intro 
{
	requires javafx.base;
    requires javafx.graphics;
    requires javafx.controls;
    
    exports fxPackage;
}