module Magic_8_Ball {
	requires javafx.base;
    requires javafx.graphics;
    requires javafx.controls;
    exports application;
}
