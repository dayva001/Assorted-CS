module AbstractInterfaces {
}