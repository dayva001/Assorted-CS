module Card_Hand {
	requires javafx.controls;
	requires javafx.base;
	requires javafx.graphics;
	
	exports application;
}
