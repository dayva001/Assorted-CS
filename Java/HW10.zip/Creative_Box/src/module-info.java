module Creative_Box {
	requires javafx.controls;
	requires javafx.base;
	requires javafx.graphics;
	
	exports application;
}
