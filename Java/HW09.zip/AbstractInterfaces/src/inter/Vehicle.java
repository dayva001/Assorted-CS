package inter;


public interface Vehicle 
{	
	void speed();
	
	void paint();
}
