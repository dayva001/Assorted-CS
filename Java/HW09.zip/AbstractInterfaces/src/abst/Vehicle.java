package abst;

public abstract class Vehicle
{
	abstract void speed();
	
	abstract void paint();
	
	void drive()
	{
		System.out.println("Ha Ha, abstract class go brrr");
	}
	
	
}
