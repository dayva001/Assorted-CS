module GUI_BusyBox 
{
	requires javafx.base;
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.media;
    exports application;
}
